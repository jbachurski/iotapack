import os

tid = "xyz"

os.system(
    f"iotapack {tid} sol/{tid}.cpp cpp in doc/{tid}.pdf"
    f"--zip --cfg cfg.yml -ps doc/{tid}.tex"
)
