
from sys import argv, exit

outwzo = open(argv[3]).read().strip()
outzaw = open(argv[2]).read().strip()



def decide(expected, got):
    ...


decision = decide(outwzo, outzaw)
if decision[0]:
    print("OK")
else:
    print("WRONG")
if decision[1]:
    print(decision[1])

exit(0)
