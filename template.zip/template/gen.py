import random
import shutil
import os
import platform
from string import ascii_lowercase

local = platform.node() == "Prism"
task_id = "xyz"
rand = random.randint

def prob(p):
    return random.random() <= p

def range_sample(r, k):
    A = []; A1 = set()
    for i in range(k):
        x = random.randrange(r.start, r.stop, r.step)
        while x in A1:
            x = random.randrange(r.start, r.stop, r.step)
        A1.add(x)
        A.append(x)
    return A

class Test:
    def __init__(self, ...):
        ...

    def __str__(self):
        return ...

    @classmethod
    def random(cls, ...):
        return ...

def next_group(num, calls, suf=ascii_lowercase):
    for i, (func, args) in enumerate(calls):
        fn = "{}{}{}.in".format(task_id, num, suf[i]) if not local else "in/{}{}.in".format(num, suf[i])
        print(fn, flush=True)
        t = func(*args)
        with open(fn, "w") as f:
            f.write(str(t))

def tpl_random(...):
    return ... # (func, args)

random.seed(1337)

next_group(0, [
    ...
])

next_group(1, [
    ...
])

next_group(2, [
    ...
])

next_group(3, [
    ...
])
